![deVStudio Feature Graphic](https://raw.githubusercontent.com/CypherpunkArmory/deVStudio/master/app/src/main/ic_main_launcher-playstore.png)

# Welcome to the deVStudio Android app

The easiest way to run Visual Studio Code on Android.

[<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png"
     alt="Get it on Google Play"
     height="80">](https://play.google.com/store/apps/details?id=tech.ula.devstudio)
     
## Have a bug report or a feature request?
You can see our templates by visiting our [issue center](https://github.com/CypherpunkArmory/deVStudio/issues).

## This is FOSS
This app is released under the GPLv3.  The source code can be found here.
This app is not created by the main VS Code development team.  Instead it is an adaptation that allows the Linux version to run on Android.
